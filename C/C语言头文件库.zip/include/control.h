#ifndef _CONTROL_H
#define _CONTROL_H
#if __GNUC__ >= 3
#pragma GCC system_header
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*--- DirectShow Reference - DirectShow Data Types */
typedef LONG_PTR OAEVENT;
typedef LONG_PTR OAHWND;

#ifdef __cplusplus
}
#endif
#endif
