inception_file = open('inception.py', 'r')
contents = inception_file.read()
print(contents)
