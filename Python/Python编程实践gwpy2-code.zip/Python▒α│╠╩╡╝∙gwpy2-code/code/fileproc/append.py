with open('topics.txt', 'a') as output_file:
    output_file.write('Software Engineering')
