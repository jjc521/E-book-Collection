with open('file_example.txt', 'r') as example_file:
    lines = example_file.readlines()

print(lines)
