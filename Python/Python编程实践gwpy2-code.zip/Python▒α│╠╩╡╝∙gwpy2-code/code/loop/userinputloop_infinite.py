while True:
    formula = input("Please enter a chemical formula: ")
    if formula == "H2O":
        print("Water")
    elif formula == "NH3":
        print("Ammonia")
    elif formula == "CH4":
        print("Methane")
    else:
        print("Unknown compound")
