def to_celsius(t):                        
    return round((t - 32.0) * 5.0 / 9.0)

def above_freezing(t):
    return t > 0
