if __name__ == "__main__":
    print("I am the main program.")
else:
    print("Another module is importing me.")
