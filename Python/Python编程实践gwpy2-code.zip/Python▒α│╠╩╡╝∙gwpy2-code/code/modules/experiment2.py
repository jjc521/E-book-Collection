print("The koala's scientific name is 'Phascolarctos cinereus'")
