import tkinter
window = tkinter.Tk()
window.mainloop()
print('Anybody home?')
