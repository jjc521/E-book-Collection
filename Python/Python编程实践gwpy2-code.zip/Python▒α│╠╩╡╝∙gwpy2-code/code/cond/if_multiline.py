ph = 8.0
if ph < 7.0:
    print(ph, "is acidic.")
print "You should be careful with that!"
