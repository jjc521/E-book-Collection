>>> lobster = Arthropod('Homarus gammarus', 0, 0, 10)
>>> print lobster
(Homarus gammarus, 0, 0)
