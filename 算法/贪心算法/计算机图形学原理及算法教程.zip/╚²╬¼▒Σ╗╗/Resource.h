//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ��ά�任.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MYTYPE                      129
#define ID_TRANSLATION                  32772
#define ID_ROTATION_X                   32774
#define ID_ROTATION_Y                   32775
#define ID_ROTATION_                    32776
#define ID_ROTATION_Z                   32776
#define ID_MIRROR_OXY                   32778
#define ID_MIRROR_Y                     32779
#define ID_MIRROR_Z                     32780
#define ID_MIRROR_O                     32781
#define ID_MIRROR_OYZ                   32784
#define ID_MIRROR_OZX                   32785
#define ID_SCALING_XYZ                  32786
#define ID_SCALING_S                    32787
#define ID_MIRROR_X                     32788
#define ID_SH_X                         32789
#define ID_SH_Y                         32790
#define ID_V                            32792
#define ID_H                            32793
#define ID_W                            32794
#define ID_PRP                          32795
#define ID_VE                           32797
#define ID_VT                           32798
#define ID_SE                           32799
#define ID_ST                           32800
#define ID_SH_Z                         32801
#define ID_1                            32802

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
