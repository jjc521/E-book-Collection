/*--------------------------------------------------------------
   HelloMsg.c -- Displays "Hello, Windows 98!" in a message box
                 (c) Charles Petzold, 1998
  --------------------------------------------------------------*/

#include <windows.h> //预处理指令（preprocessor）指令：
/*
windows.h是一个最重要的包含文件，它囊括了若干其他的windows头文件，其中某些头文件又包括另外一些头文件，几个最重要的文件如下：
WINDEF.H 基本数据类型定义。
WINNT.H 支持Unicode的类型定义。
WINBASE.H 内核函数。
WINUSER.H 用户界面函数。
WINGDI.H 图形设备接口函数。
*/
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
/*WINMIN是Windows程序的入口*/
{
     MessageBox (NULL, TEXT ("Hello, Windows 98!"), TEXT ("HelloMsg"), 0) ;
     return 0 ;
}
